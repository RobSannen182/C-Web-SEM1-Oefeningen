﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCWebApp.Models
{
    public class ClientLocationModel
    {
        public ClientLocationModel()
        {
            var clients = Data.Databank.Clients;
            var locations = Data.Databank.Locations;
            var query = clients.Join(locations, k => k.LocationId, l => l.LocationId,
                (k, l) => new { Name = k.ClientName, City = l.City });
        }
    }
}
