﻿using Microsoft.AspNetCore.Mvc;
using MVCOefening07.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCOefening07.Controllers
{
    public class MedewerkersController : Controller
    {
        public IActionResult Index()
        {
            var lstMedewerkers = Enumerable.Empty<Medewerker>();
            return View(lstMedewerkers);
        }
        [HttpGet]
        public IActionResult Create()
        {
            var medewerker = new Medewerker();
            return View(medewerker);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Medewerker medewerker)
        {
            if (ModelState.IsValid)
            {
                AddMedewerker(medewerker);
                return RedirectToAction("Index");
            }
            return View(medewerker);
        }
        private void AddMedewerker(Medewerker medewerker)
        {
            //Database actions
        }
    }
}
