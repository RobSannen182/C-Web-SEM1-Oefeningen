﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MVCPXLParty2021.Migrations
{
    public partial class EenOpVeelRelaties : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
